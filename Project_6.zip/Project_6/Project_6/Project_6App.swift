//
//  Project_2App.swift
//  Project 6
//
//  Created by Ann Jordan on 3/20/26.
//

import SwiftUI

@main
struct Project_6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
