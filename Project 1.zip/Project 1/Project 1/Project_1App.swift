//
//  Project_1App.swift
//  Project 1
//
//  Created by Ann Jordan on 1/28/26.
//

import SwiftUI

@main
struct Project_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
