//
//  ContentView.swift
//  Project 1
//
//  Created by Ann Jordan on 1/28/26.
//

import SwiftUI

struct ContentView: View {
    let tipPercentages = [5, 10, 15, 20, 0]
    let customTag = 50
    
    @State private var checkAmount = 0.0
    @State private var numberOfPeople = 2
    @State private var tipPercentage = 20
    @State private var showCustom = false
        
    @FocusState private var amountIsFocused: Bool
    
    var totalPerPerson: Double {
        let peopleCount = Double(numberOfPeople + 2)
        let amountPerPerson = grandTotal / peopleCount
        
        return amountPerPerson
    }
    
    var grandTotal: Double {
        let tipSelection = Double(tipPercentage)
        let tipValue = checkAmount / 100 * tipSelection
        
        return checkAmount + tipValue
    }
    
    var body: some View {
        NavigationStack{
            Form {
                Section("Subtotal:") {
                    TextField("Amount", value: $checkAmount, format: .currency(code: Locale.current.currency?.identifier ?? "USD"))
                }
                .focused($amountIsFocused)
                .keyboardType(.decimalPad)
                
                // Perplexity https://www.perplexity.ai/search/hstack-picker-tip-percentage-s-kSdtgwYTSO.GE8utSiwhUg
                Section("How much tip do you want to leave?") {
                    Picker("Tip percentage", selection: $tipPercentage) {
                        ForEach(tipPercentages, id: \.self) { percentage in
                            Text("\(percentage)%")
                                .tag(percentage)
                        }
                        Text("Custom")
                            .tag(customTag)
                    }
                    .pickerStyle(.segmented)
                }
                .onChange(of: tipPercentage) { oldValue, newValue in
                    if newValue == customTag {
                        showCustom = true
                    }
                }
                .navigationDestination(isPresented: $showCustom) {
                    TipPercentageView(tipPercentage: $tipPercentage)
                }
                
                
                Picker("Number of people", selection: $numberOfPeople) {
                    ForEach(2..<100) {
                        Text("\($0) people")
                    }
                }
                
                .pickerStyle(.navigationLink)
                
                Section("Amount per person:") {
                    Text(totalPerPerson, format: .currency(code: Locale.current.currency?.identifier ?? "USD"))
                }
                
                Section("Total:") {
                    Text(grandTotal, format: .currency(code: Locale.current.currency?.identifier ?? "USD"))
                }
            }
            .navigationTitle("WeSplit")
            .toolbar {
                if amountIsFocused {
                    Button("Done") {
                        amountIsFocused = false
                    }
                }
            }
        }
    }
}

struct TipPercentageView: View {
    @Binding var tipPercentage: Int
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    VStack {
                        Text("\(tipPercentage)%")
                            .font(.largeTitle)
                            .monospacedDigit()
                        Slider(value: Binding(
                            get: { Double(tipPercentage) },
                            set: { tipPercentage = Int($0) }
                        ), in: 0...100, step: 1)
                    }
                    .padding(.vertical)
                }
            }
            .navigationTitle("Tip")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
