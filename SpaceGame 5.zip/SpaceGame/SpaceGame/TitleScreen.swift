//
//  titleScreen.swift
//  SpaceGame
//
//  Created by Ann Jordan on 4/17/26.
//

import SpriteKit

class TitleScreen: SKScene {
    override func didMove(to view: SKView) {
        //do setup like emitter nodes for stars
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let view = self.view {
            if let scene = SKScene(fileNamed: "GameScene") {
                scene.scaleMode = .aspectFill
                let transition = SKTransition.doorsOpenHorizontal(withDuration: 2)
                view.presentScene(scene, transition: transition)
            }
        }
    }
}
