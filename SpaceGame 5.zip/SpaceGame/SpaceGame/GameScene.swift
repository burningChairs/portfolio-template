//
//  GameScene.swift
//  SpaceGame
//
//  Created by Ann Jordan on 4/7/26.
//

import SpriteKit
import GameplayKit
import AVFoundation

class GameScene: SKScene, SKPhysicsContactDelegate {
    final var player: SKSpriteNode!
    var isMoving = false
    var score = 0
    var isAutofiring = false
    
    //    var backgroundMusic: SKAudioNode!
    let backgroundMusic = SKAudioNode(fileNamed: "music.m4a")
    
    
    let explosion = SKAction.playSoundFileNamed("explosion.wav", waitForCompletion: false)
    let laserSound = SKAction.playSoundFileNamed("laser.wav", waitForCompletion: false)
    let yaySound = SKAction.playSoundFileNamed("yay.mp3", waitForCompletion: false)
    
    
    var laserSpeedMultiplier: CGFloat = 1.0
    let powerUpDuration: TimeInterval = 1.0
    let normalLaserDuration: TimeInterval = 1.0
    
    let scoreLabel = SKLabelNode(text: "Score: 0")
    
    let noCategory: UInt32 = 0
    let playerCategory: UInt32 = 0b1        //0001
    let laserCategory: UInt32 = 0b1 << 1    //0010
    let enemyCategory: UInt32 = 0b1 << 2    //0100
    let powerUpCategory: UInt32 = 0b1 << 3  //1000
    // contactMask                          //0101
    
    //    let starsEmmitter = CAEmitterLayer()
    
    override func didMove(to view: SKView) {
        backgroundMusic.run(.changeVolume(by: 2.0, duration: 0.5))
        addChild(backgroundMusic)
        
        
        player = childNode(withName: "player") as? SKSpriteNode
        player.physicsBody?.categoryBitMask = playerCategory
        
        // TODO: Add other bitmasks for player
        
        let stars = childNode(withName: "starsEmitter") as? SKEmitterNode
        stars?.advanceSimulationTime(20)
        
        self.addChild(scoreLabel)
        scoreLabel.fontSize = 200
        scoreLabel.position = CGPoint(x: frame.midX, y: frame.minY + 100)
        
        run(SKAction.repeatForever(.sequence([
            .wait(forDuration: 2.0),
            .run { self.spawnEnemy() }
        ])))
        
        run(SKAction.repeatForever(.sequence([
            .wait(forDuration: 5.0),
            .run { self.spawnPowerUp() }
        ])))
        
        physicsWorld.contactDelegate = self
        view.showsPhysics = true
        
        physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
    }
    
    //--MARK: CONTACTS--
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA
        let bodyB = contact.bodyB
        let contactMask = bodyA.categoryBitMask | bodyB.categoryBitMask
        
        if contactMask == (laserCategory | enemyCategory) {
            let laserBody = (bodyA.categoryBitMask == laserCategory) ? bodyA : bodyB
            let enemyBody = (bodyA.categoryBitMask == enemyCategory) ? bodyA : bodyB
            
            
            if let enemyNode = enemyBody.node {
                createExplosion(at: enemyNode.position)
            }
            
            
            run(explosion)
            
            laserBody.node?.removeFromParent()
            enemyBody.node?.removeFromParent()
            
            score += 1
            scoreLabel.text = "Score: \(score)"
        } else if contactMask == (playerCategory | enemyCategory) {
            if let view = self.view {
                if let scene = SKScene(fileNamed: "TitleScreen") {
                    scene.scaleMode = .aspectFill
                    scene.run(yaySound)
                    let transition = SKTransition.doorsOpenHorizontal(withDuration: 2)
                    view.presentScene(scene, transition: transition)
                }
            }
        } else if contactMask == (playerCategory | powerUpCategory) {
            let powerUpBody = (bodyA.categoryBitMask == powerUpCategory) ? bodyA : bodyB
            powerUpBody.node?.removeFromParent()
            
            laserSpeedMultiplier = 4.0
            isAutofiring = true
            spawnLaser()
            
            let reset = SKAction.sequence([
                SKAction.wait(forDuration: powerUpDuration),
                SKAction.run { [weak self] in
                    self?.laserSpeedMultiplier = 1.0
                    self?.isAutofiring = false
                }
            ])
            run(reset)
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isMoving = false
        guard let touchPosition = touches.first?.location(in: self) else { return }
        if player.contains(touchPosition) {
            player.position = touchPosition
            spawnLaser()
            isMoving = true
        }
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touchPosition = touches.first?.location(in: self) else { return }
        if player.contains(touchPosition) || isMoving {
            isMoving = true
            player.position = touchPosition
            if isAutofiring {
                spawnLaser()
            }
        }
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        for node in children {
            if node.position.y < -size.height / 2 - 200 ||
                node.position.y > size.height / 2 + 200 ||
                node.position.x < -size.height / 2 - 200 ||
                node.position.x > size.height / 2 + 200 {
                node.removeFromParent()
            }
        }
    }
    
    //--MARK: SPAWNING--
    func createExplosion(at position:CGPoint){
        if let explosion = SKEmitterNode(fileNamed: "Explosion") {
            explosion.position = position
            explosion.zPosition = 3
            addChild(explosion)
            
            let wait = SKAction.wait(forDuration: 1.0)
            let remove = SKAction.removeFromParent()
            explosion.run(SKAction.sequence([wait, remove]))
        }
    }
    
    func spawnLaser() {
        if let scene = SKScene(fileNamed: "Laser.sks") {
            if let laser = scene.childNode(withName: "laser") as? SKSpriteNode {
                laser.position = player.position
                laser.zPosition = 2
                
                //                laser.physicsBody = SKPhysicsBody(rectangleOf: laser.size)
                //                laser.physicsBody?.isDynamic = true
                //                laser.physicsBody?.affectedByGravity = false
                laser.physicsBody?.categoryBitMask = laserCategory
                laser.physicsBody?.contactTestBitMask = enemyCategory
                laser.physicsBody?.collisionBitMask = 0
                
                laser.move(toParent: self)
                
                
                run(laserSound)
                
                let laserDuration = normalLaserDuration / TimeInterval(laserSpeedMultiplier)
                
                let moveUp = SKAction.moveBy(x: 0, y: size.height, duration: laserDuration)
                
                let remove = SKAction.removeFromParent()
                laser.run(SKAction.sequence([moveUp, remove]))
                
                
            }
        }
    }
    
    
    func spawnEnemy() {
        let enemy = SKSpriteNode(imageNamed: "enemy_frame3")
        enemy.size = CGSize(width: 130, height: 130)
        enemy.position = CGPoint(
            x: CGFloat.random(in: -size.width / 2...size.width / 2),
            y: size.height / 2 + 100
        )
        enemy.zPosition = 1
        
        enemy.physicsBody = SKPhysicsBody(rectangleOf: enemy.size)
        enemy.physicsBody?.isDynamic = true
        enemy.physicsBody?.affectedByGravity = false
        enemy.physicsBody?.categoryBitMask = enemyCategory
        enemy.physicsBody?.contactTestBitMask = laserCategory | playerCategory
        enemy.physicsBody?.collisionBitMask = 0
        addChild(enemy)
        
        
        var textures: [SKTexture] = []
        for i in 1...4 {
            textures.append(SKTexture(imageNamed: "enemy_frame\(i)"))
        }
        enemy.run(.repeatForever(.animate(with: textures, timePerFrame: 0.5)))
        
        enemy.run(.sequence([
            .wait(forDuration: 4.0),
            .removeFromParent()
        ]))
        
        let angleToPlayer = angle(from: enemy.position, to: player.position)
        let enemySpeed = 1000.0
        enemy.physicsBody?.velocity = polarToVector(enemySpeed, angleToPlayer)
        
    }
    
    func spawnPowerUp() {
        if Float.random(in: 0...1) < 0.5 {
            let powerUp = SKSpriteNode(imageNamed: "powerup")
            powerUp.size = CGSize(width: 100, height: 100)
            let startY = CGFloat.random(in: -size.height / 2...size.height / 2)
            let startX = -size.width / 2 - 50
            
            powerUp.position = CGPoint(x: startX, y: startY)
            powerUp.zPosition = 1
            powerUp.zPosition = 1
            
            powerUp.physicsBody = SKPhysicsBody(rectangleOf: powerUp.size)
            powerUp.physicsBody?.isDynamic = true
            powerUp.physicsBody?.affectedByGravity = false
            //bit mask should be variable
            powerUp.physicsBody?.categoryBitMask = powerUpCategory
            powerUp.physicsBody?.contactTestBitMask = playerCategory
            powerUp.physicsBody?.collisionBitMask = 0
            addChild(powerUp)
            
            let endX = size.width / 2 + 50
            let moveDuration = 6.0
            
            powerUp.run(.sequence([
                .moveTo(x: endX, duration: moveDuration),
                .removeFromParent()
            ]))
        }
    }
    func angle(from origin: CGPoint, to destination: CGPoint) -> Double {
        let deltaX = Double(destination.x - origin.x)
        let deltaY = Double(destination.y - origin.y)
        return atan2(deltaY, deltaX)
    }
    
    func polarToPoint(_ r: Double, _ angle: Double) -> CGPoint {
        CGPoint(x: r * cos(angle), y: r * sin(angle))
    }
    
    func polarToVector(_ r: Double, _ angle: Double) -> CGVector {
        let p = polarToPoint(r, angle)
        return CGVector(dx: p.x, dy: p.y)
    }
}
