//
//  ContentView.swift
//  Project 2
//
//  Created by Ann Jordan on 2/2/26.
//

import SwiftUI

struct ContentView: View {
    @State private var showingScore = false
    @State private var scoreTitle = ""
    @State private var countries = ["Estonia", "France", "Germany", "Ireland", "Italy", "Nigeria", "Poland", "Spain", "UK", "Ukraine", "US"].shuffled()
    @State private var correctAnswer = Int.random(in: 0...2)
    @State private var score = 0
    
    @State private var questionCount = 0
    let maxQuestions = 8
    
    var body: some View {
        ZStack {
            RadialGradient(stops: [
                .init(color: Color(red: 0.1, green: 0.2, blue: 0.45), location: 0.3),
                .init(color: Color(red: 0.76, green: 0.15, blue: 0.26), location: 0.3),
            ], center: .top, startRadius: 150, endRadius: 500)
            .ignoresSafeArea()
            
            VStack {
                Text("Guess the Flag")
                    .font(.largeTitle.weight(.bold))
                    .foregroundStyle(.white)
                
                if questionCount < maxQuestions {
                    
                    VStack(spacing: 15) {
                        Text("Tap the flag of")
                            .font(.subheadline.weight(.heavy))
                            .foregroundStyle(.secondary)
                        Text(countries[correctAnswer])
                            .font(.largeTitle.weight(.semibold))
                            .shadow(radius: 10)
                            .foregroundStyle(.white)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 20)
                    .background(.regularMaterial)
                    .clipShape(.rect(cornerRadius: 20))
                
                
                    Text("Score: \(score)")
                        .foregroundStyle(.white)
                        .font(.title.bold())
    
                    Text("Question \(questionCount + 1) / \(maxQuestions)")
                        .foregroundStyle(.white)
                }
                
                if questionCount < maxQuestions {
                    VStack {
                        ForEach(0..<3, id: \.self) { number in
                            Button {
                                flagTapped(number)
                            } label: {
                                Image(countries[number])
                                    .clipShape(.capsule)
                                    .shadow(radius: 10)
                            }
                        }
                    }
                    
                    .alert(scoreTitle, isPresented: $showingScore) {
                        Button("Continue", action: askQuestion)
                    } message: {
                        Text("Your score is \(score)")
                    }
                    
                } else {
                    Text("Game over!")
                        .font(.title3)
                        .foregroundStyle(.white)
                        .padding(.top)
                    
                    Text("Final score: \(score)/8")
                        .foregroundStyle(.white)
                        .font(.title)
                    
                    Button("restart game") {
                        restartGame()
                    }
                    .padding()
                    .background(.white)
                    .foregroundStyle(.black)
                    .clipShape(Capsule())
                }
            }
            .padding()
        }
    }
    func flagTapped(_ number: Int) {
        if number == correctAnswer {
           // scoreTitle = "Correct - the answer was \(countries[correctAnswer])"
            score += 1
            //showingScore = false
            countries.shuffle()
            correctAnswer = Int.random(in: 0...2)
            questionCount += 1
            
        } else {
            scoreTitle = "Wrong - you chose \(countries[number]) : the answer was \(countries[correctAnswer])"
            showingScore = true
        }
        //showingScore = true
    }
    
    func askQuestion() {
        questionCount += 1

        if questionCount < maxQuestions {
            countries.shuffle()
            correctAnswer = Int.random(in: 0...2)
        }
    }

    func restartGame() {
        score = 0
        questionCount = 0
        countries.shuffle()
        correctAnswer = Int.random(in: 0...2)
    }
}

#Preview {
    ContentView()
}
