//
//  Project_2App.swift
//  Project 2
//
//  Created by Ann Jordan on 2/2/26.
//

import SwiftUI

@main
struct Project_2App: App {    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
