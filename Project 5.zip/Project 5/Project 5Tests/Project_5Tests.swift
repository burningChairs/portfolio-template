//
//  Project_5Tests.swift
//  Project 5Tests
//
//  Created by Ann Jordan on 3/3/26.
//

import Testing
@testable import Project_5

struct Project_5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
