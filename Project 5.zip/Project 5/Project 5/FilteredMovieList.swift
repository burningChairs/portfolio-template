//
//  FilteredMovieList.swift
//  Project 5
//
//  Created by Ann Jordan on 3/4/26.
//

import SwiftUI
import SwiftData

struct FilteredMovieList: View {
    @State private var searchText = ""
    @State private var sortByReleaseDate = false
    
    var body: some View {
        NavigationSplitView {
            MovieList(titleFilter: searchText, sortByReleaseDate: sortByReleaseDate)
                .searchable(text: $searchText)
                .toolbar {
                    ToolbarItem {
                        Toggle("Sort by date", isOn: $sortByReleaseDate)
                    }
                }
        } detail: {
            Text("Select a movie")
                .navigationTitle("Movie")
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    FilteredMovieList()
        .modelContainer(SampleData.shared.modelContainer)
}
