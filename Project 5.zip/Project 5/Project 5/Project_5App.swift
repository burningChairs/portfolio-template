//
//  Project_5App.swift
//  Project 5
//
//  Created by Ann Jordan on 3/3/26.
//

import SwiftUI
import SwiftData

@main
struct Project_5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [Movie.self, Friend.self])
    }
}
