//
//  Friend.swift
//  Project 5
//
//  Created by Ann Jordan on 3/3/26.
//

import Foundation
import SwiftData

@Model
class Friend {
    var name: String
    var favoriteMovie: Movie?
    var favoritedBy = [Friend]()
    
    init(name: String) {
        self.name = name
    }
    
    static let sampleData = [
        Friend(name: "Edrick"),
        Friend(name: "Helena"),
        Friend(name: "Ollie"),
        Friend(name: "Amy-Lee"),
        Friend(name: "Vic"),
    ]
}
