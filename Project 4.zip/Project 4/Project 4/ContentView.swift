////
////  ContentView.swift
////  Project 4
////
////  Created by Ann Jordan on 2/20/26.
////
//
//import SwiftUI
//import SwiftData
//
//struct ContentView: View {
//    //@Query(sort: \Buddy.birthday) private var buddies: [Buddy]
//    @Query private var buddies: [Buddy]
//    @Environment(\.modelContext) private var context
//    
////    @State private var buddies: [Buddy] = [
////        Buddy(name: "Elliot Alderson", birthday: .now),
////        Buddy(name: "Edrick Medina", birthday: Date(timeIntervalSince1970: 0))
////    ]
//    
//    @State private var newName = ""
//    @State private var newDate = Date.now
//    
//    var body: some View {
//        NavigationStack {
//            List(buddies) { buddy in
//                HStack {
//                    if buddy.isBirthdayToday {
//                        Image(systemName: "birthday.cake")
//                    }
//                    Text(buddy.name)
//                        .bold(buddy.isbirthdayToday)
//                    Spacer()
//                    Text(buddy.birthday, format: .dateTime.month(.wide).day().year())
//                }
//            }
//            .navigationTitle("Birthdays")
//            .safeAreaInset(edge: .bottom) {
//                VStack(alignment: .center, spacing: 20) {
//                    Text("New Birthday")
//                        .font(.headline)
//                    DatePicker(selection: $newDate, in: Date.distantPast...Date.now, displayedComponents: .date) {
//                        TextField("Name", text: $newName)
//                            .textFieldStyle(.roundedBorder)
//                    }
//                    Button("Save") {
//                        let newBuddy = Buddy(name: newName, birthday: newDate)
//                        context.insert(newBuddy)
//                        
//                        newName = ""
//                        newDate = .now
//                    }
//                    .bold()
//                }
//                .padding()
//                .background(.bar)
//            }
//            .task {
//                context.insert(Buddy(name: "Elliot Alderson", birthday: .now))
//                context.insert(Buddy(name: "Edrick Medina", birthday: Date(timeIntervalSince1970: 0)))
//            }
//        }
//    }
//}
//
//#Preview {
//    ContentView()
//        .modelContainer(for: Buddy.self, inMemory: true)
//}


import SwiftUI
import SwiftData


struct ContentView: View {
//    @State private var buddies: [Buddy] = [
//        Buddy(name: "Elton Lin", birthday: .now),
//        Buddy(name: "Jenny Court", birthday: Date(timeIntervalSince1970: 0))
//    ]
    //@Query private var buddies: [Buddy]
    //@Query(sort: \Buddy.birthday) private var buddies: [Buddy]
    @Query(sort: \Buddy.name) private var buddies: [Buddy]
    @Environment(\.modelContext) private var context
    
    @State private var newName = ""
    @State private var newNotes = ""
    @State private var newDate = Date.now

    var body: some View {
        NavigationStack {
            List(buddies) { buddy in
                HStack {
                    if buddy.isBirthdayToday {
                        Image(systemName: "birthday.cake")
                    }
                    
                    VStack(alignment: .leading) {
                        Text(buddy.name)
                            .bold(buddy.isBirthdayToday)
                        
                        if !buddy.notes.isEmpty {
                            Text(buddy.notes)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    
                    Spacer()
                    Text(buddy.birthday, format: .dateTime.month(.wide).day().year())
                }
            }
            .navigationTitle("Birthdays")
            .safeAreaInset(edge: .bottom) {
                VStack(alignment: .center, spacing: 20) {
                    Text("New Birthday")
                        .font(.headline)
                    /*DatePicker(selection: $newDate, in: Date.distantPast...Date.now, displayedComponents: .date)*/
                    TextField("Name", text: $newName)
                        .textFieldStyle(.roundedBorder)
                    DatePicker("Birthday", selection: $newDate, displayedComponents: .date)
//                    {
//                        TextField("Name", text: $newName)
//                            .textFieldStyle(.roundedBorder)
//                    }
                    TextField("Notes (planning, presents, etc.)", text: $newNotes)
                        .textFieldStyle(.roundedBorder)
                    Button("Save") {
                        let newBuddy = Buddy(name: newName, birthday: newDate, notes: newNotes)
                        context.insert(newBuddy)


                        newName = ""
                        newNotes = ""
                        newDate = .now
                    }
                    .bold()
                }
                .padding()
                .background(.bar)
            }
//            .task {
//                context.insert(Buddy(name: "Elton Lin", birthday: .now))
//                context.insert(Buddy(name: "Jenny Court", birthday: Date(timeIntervalSince1970: 0)))
//                
//            }
        }
    }
}


#Preview {
    ContentView()
        .modelContainer(for: Buddy.self, inMemory: true)
}
