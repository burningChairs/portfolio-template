//
//  Project_4App.swift
//  Project 4
//
//  Created by Ann Jordan on 2/20/26.
//

import SwiftUI
import SwiftData

@main
struct BirthdaysApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .modelContainer(for: Buddy.self)
        }
    }
}
