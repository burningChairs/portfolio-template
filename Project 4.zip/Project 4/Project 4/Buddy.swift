//
//  Buddy.swift
//  Project 4
//
//  Created by Ann Jordan on 2/20/26.
//

import Foundation
import SwiftData

@Model
class Buddy {
    var name: String
    var birthday: Date
    var notes: String
    
    init(name: String, birthday: Date, notes: String) {
        self.name = name
        self.birthday = birthday
        self.notes = notes
    }
    
    var isBirthdayToday: Bool {
        Calendar.current.isDateInToday(birthday)
    }
}
