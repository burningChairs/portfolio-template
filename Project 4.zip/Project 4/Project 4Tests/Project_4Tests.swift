//
//  Project_4Tests.swift
//  Project 4Tests
//
//  Created by Ann Jordan on 2/20/26.
//

import Testing
@testable import Project_4

struct Project_4Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
