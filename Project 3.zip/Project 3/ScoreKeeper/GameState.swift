//
//  GameState.swift
//  Project 3
//
//  Created by Ann Jordan on 2/10/26.
//

import Foundation

enum GameState {
    case setup
    case playing
    case gameOver
}
