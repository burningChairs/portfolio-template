//
//  Project_3App.swift
//  Project 3
//
//  Created by Ann Jordan on 2/9/26.
//

import SwiftUI

@main
struct Project_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
