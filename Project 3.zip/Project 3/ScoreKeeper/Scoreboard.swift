//
//  Scoreboard.swift
//  Project 3
//
//  Created by Ann Jordan on 2/10/26.
//

import Foundation

struct Scoreboard {
    var players: [Player] = [
        Player(name: "Edrick", score: 0),
        Player(name: "Edger", score: 0),
        Player(name: "Ed-Rick", score: 0),
    ]
    
    var state = GameState.setup
    var doesHighestScoreWin = true
    
    var totalRounds: Int = 1
    var currentRound: Int = 0
    
    var winners: [Player] {
        guard state == .gameOver else { return [] }
        
        var winningScore = 0
        if doesHighestScoreWin {
            winningScore = Int.min
            for player in players {
                winningScore = max(player.score, winningScore)
            }
        } else {
            winningScore = Int.max
            for player in players {
                winningScore = min(player.score, winningScore)
            }
        }
        
        return players.filter { player in
            player.score == winningScore
        }
    }
    
    mutating func resetScores(to newValue: Int) {
        for index in 0..<players.count {
            players[index].score = newValue
        }
        currentRound = 0
    }
    
    mutating func advanceRound() {
        guard state == .playing else { return }
        currentRound += 1
        if currentRound >= totalRounds {
            state = .gameOver
        }
    }
}
