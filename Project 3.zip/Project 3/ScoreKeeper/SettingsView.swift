//
//  SettingsView.swift
//  ScoreKeeper
//
//  Created by Ann Jordan on 2/10/26.
//

import SwiftUI

struct SettingsView: View {
    @Binding var doesHighestScoreWin: Bool
    @Binding var startingPoints: Int
    
    @Binding var totalRounds: Int
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Game Rules")
                .font(.headline)
            Divider()
            Picker("Win condition", selection: $doesHighestScoreWin) {
                Text("Highest Score Wins")
                    .tag(true)
                Text("Lowest Score Wins")
                    .tag(false)
            }
            Picker("Starting points", selection: $startingPoints) {
                Text("0 starting points")
                    .tag(0)
                Text("10 starting points")
                    .tag(10)
                Text("20 starting points")
                    .tag(20)
            }
            Picker("number of rounds", selection: $totalRounds) {
                Text("1 round").tag(1)
                Text("3 round").tag(3)
                Text("5 round").tag(5)
            }
        }
        .padding()
        .background(.thinMaterial, in: .rect(cornerRadius: 10.0))
    }
}
#Preview {
    @Previewable @State var doesHighestScoreWin = true
    @Previewable @State var startingPoints = 10
    
    @Previewable @State var totalRounds = 3
    SettingsView(
        doesHighestScoreWin: $doesHighestScoreWin,
        startingPoints: $startingPoints,
        totalRounds: $totalRounds
    )
    
    //SettingsView(doesHighestScoreWin: $scoreboard.doesHighestScoreWin, //startingPoints: $startingPoints)
        //.disabled(scoreboard.state != .setup)
}
