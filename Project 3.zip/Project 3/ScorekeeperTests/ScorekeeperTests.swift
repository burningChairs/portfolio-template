//
//  ScorekeeperTests.swift
//  ScorekeeperTests
//
//  Created by Ann Jordan on 2/10/26.
//

import Testing
@testable import ScoreKeeper

struct ScorekeeperTests {
    
    @Test("Reset player scores", arguments: [0, 10, 20])
    func resetScores(to newValue: Int) async throws {
        var scoreboard = Scoreboard(players: [
            Player(name: "Edrick", score: 0),
            Player(name: "Edger", score: 5),
        ])
        await scoreboard.resetScores(to: newValue)
        
        for player in await scoreboard.players {
            #expect(player.score == newValue)
        }
    }
    
//    Code created multiple warnings:
    
//    @Test("Multiple winners with equal high scores")
//    func multipleWinners() async throws {
//        var scoreboard = Scoreboard(players: [
//            Player(name: "Edrick", score: 10),
//            Player(name: "Edger", score: 10),
//            Player(name: "Ed-Rick", score: 5),
//        ])
//        scoreboard.state = .gameOver
//        
//        let winners = await scoreboard.winners
//        
//        assert(winners.contains(where: { $0.name == "Edrick" }), "Edrick should be a winner")
//        assert(winners.contains(where: { $0.name == "Edger" }), "Edger should be a winner")
//        assert(!winners.contains(where: { $0.name == "Ed-Rick" }), "Ed-Rick should not be a winner")
//        assert(winners.count == 2, "There should be exactly two winners")
//    }
    
    @Test("Multiple winner with equal high scores")
    func multipleWinners() async throws {
        var scoreboard = Scoreboard(players: [
            Player(name: "Edrick", score: 10),
            Player(name: "Edger", score: 10),
            Player(name: "Ed-Rick", score: 5),
        ],
        state: .gameOver,
        doesHighestScoreWin: true
        )
        let winners = await scoreboard.winners
        #expect(winners == [Player(name: "Edrick", score: 4), Player(name: "Edger", score: 4)])
    }
    
    @Test("Highest score wins")
    func highestScoreWins() {
        let scoreboard = Scoreboard(
            players: [
                Player(name: "Edrick", score: 0),
                Player(name: "Edger", score: 4),
            ],
            state: .gameOver,
            doesHighestScoreWin: true
        )
        let winners = scoreboard.winners
        #expect(winners == [Player(name: "Edger", score: 4)])
    }
    
    @Test("Lowest score wins")
    func lowestScoreWins() {
        let scoreboard = Scoreboard(
            players: [
                Player(name: "Edrick", score: 0),
                Player(name: "Edger", score: 4),
            ],
            state: .gameOver,
            doesHighestScoreWin: false
        )
        let winners = scoreboard.winners
        #expect(winners == [Player(name: "Edrick", score: 0)])
    }
    
    @Test("Game ends after specified number of rounds")
    func gameEndsAfterTotalRounds() async throws {
        var scoreboard = Scoreboard(
            players: [
                Player(name: "Edrick", score: 0),
                Player(name: "Edger", score: 0),
            ],
            state: .playing,
            doesHighestScoreWin: true,
            totalRounds: 3,
            currentRound: 0
        )
        //let winners = scoreboard.winners
        await scoreboard.advanceRound()
        await scoreboard.advanceRound()
        #expect(scoreboard.state == .playing)
        #expect(scoreboard.currentRound == 2)
        
        await scoreboard.advanceRound()
        #expect(scoreboard.state == .gameOver)
        #expect(scoreboard.currentRound == 3)
        //#expect(winners == [Player(name: "Edrick", score: 0)])
    }
}
